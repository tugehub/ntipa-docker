
// Nice scroll
jQuery(function($) {
	$("html").niceScroll({
		cursorborder:"", 
		cursorcolor:"#525252", 
		boxzoom:true, 
		cursoropacitymin: 0.5,
		cursoropacitymax: 1,
		cursorwidth: 5,
		mousescrollstep: 50
	});
});
